# -*- coding: utf-8 -*-

import os
import xbmc, xbmcgui
import shutil
import zipfile
import contextlib
import glob
import urllib, os, re, urllib2


def DeleteDir(dir):
    if os.path.isdir(dir):
	shutil.rmtree(dir)

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("עדכון","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
	
	
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()


	

if int(xbmc.getInfoLabel('System.BuildVersion')[:2]) == 17:	
	
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )	
	
	
	urlzip ='https://www.dropbox.com/s/jlm52fb22ywqigk/addons.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/addons.zip")
	
	urlzip ='https://www.dropbox.com/s/k0msf8o6gu13b9e/media.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/media.zip")
	
	urlzip ='https://www.dropbox.com/s/39eptuuwa5d9kr5/userdata.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/userdata.zip")
	progress = xbmcgui.DialogProgress()
	progress.create('Myko', 'מתבצע עדכון')
	xbmc.sleep( 2000 )

	progress.update( 10, "", "מעדכן", "" )
	


	progress.update( 20, "", "מעדכן", "" )
	xbmc.sleep( 2000 )
	if os.path.isfile('/sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata/g'):
		os.remove('/sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata/g')	

	os.rename('/sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata/guisettings.xml','/sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata/g')

	

	progress.update( 30, "", "מעדכן", "" )
	xbmc.sleep( 2000 )
	

	progress.update( 40, "", "מעדכן", "" )
	xbmc.sleep( 2000 )
	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/addons.zip' , "r")) as z:
		z.extractall("/")
	
	
	progress.update( 50, "", "מעדכן", "" )

	
	xbmc.sleep( 2000 )
	
	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/userdata.zip' , "r")) as z:
		z.extractall("/")



	progress.update( 60, "", "מעדכן", "" )
	xbmc.sleep( 2000 )

	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/media.zip' , "r")) as z:
		z.extractall("/")

		
	progress.update( 75, "", "מעדכן", "" )
	xbmc.sleep( 2000 )
	os.remove('sdcard/DCIM/addons.zip')
	xbmc.sleep( 2000 )
	os.remove('/sdcard/DCIM/userdata.zip')
	xbmc.sleep( 2000 )
	os.remove('/sdcard/DCIM/media.zip')
	xbmc.sleep( 2000 )
	progress.update( 99, "", "מסיים עדכון", "" )

	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

	xbmcgui.Dialog().ok("MyKo","בוצע","אנא הפעל מחדש את המכשיר")
	os._exit(1)
	
else:
	xbmcgui.Dialog().ok("MyKo","בוצע","המערכת במכשיר זה מישונת ואל ניתנת לשדרוג")


