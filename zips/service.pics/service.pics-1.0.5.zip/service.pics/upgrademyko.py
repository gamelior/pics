# -*- coding: utf-8 -*-

import os
import xbmc, xbmcgui
import shutil
import zipfile
import contextlib
import glob
import urllib, os, re, urllib2


def DeleteDir(dir):
    if os.path.isdir(dir):
	shutil.rmtree(dir)

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("עדכון","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
	
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()


	

if int(xbmc.getInfoLabel('System.BuildVersion')[:2]) == 17:	
	progress = xbmcgui.DialogProgress()
	progress.create('Myko', 'מתבצע עדכון')
	progress.update( 10, "", "מתחיל בעדכון", "" )

	xbmc.executebuiltin( "ActivateWindow(busydialog)" )	

		
	urlzip ='https://www.dropbox.com/s/jlm52fb22ywqigk/addons.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/addons.zip")


	progress.update( 20, "", "מעדכן", "" )




	urlzip ='https://www.dropbox.com/s/k0msf8o6gu13b9e/media.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/media.zip")


	progress.update( 30, "", "מעדכן", "" )

	urlzip ='https://www.dropbox.com/s/39eptuuwa5d9kr5/userdata.zip?dl=1'
	DownloaderClass(urlzip,"/sdcard/DCIM/userdata.zip")

	progress.update( 40, "", "מעדכן", "" )
	DeleteDir("/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons")


	progress.update( 50, "", "מעדכן", "" )


	DeleteDir("/sdcard/Android/data/org.xbmc.kodi/files/.kodi/userdata")

	progress.update( 60, "", "מעדכן", "" )

	DeleteDir("/sdcard/Android/data/org.xbmc.kodi/files/.kodi/media")

	progress.update( 70, "", "מעדכן", "" )

	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/addons.zip' , "r")) as z:
		z.extractall("/")
	
	
	progress.update( 80, "", "מעדכן", "" )


	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/userdata.zip' , "r")) as z:
		z.extractall("/")



	progress.update( 90, "", "מעדכן", "" )


	with contextlib.closing(zipfile.ZipFile('/sdcard/DCIM/media.zip' , "r")) as z:
		z.extractall("/")

		
	

	os.remove('sdcard/DCIM/addons.zip')
	os.remove('/sdcard/DCIM/userdata.zip')
	os.remove('/sdcard/DCIM/media.zip')

	progress.update( 99, "", "מסיים עדכון", "" )

	xbmc.executebuiltin( "Dialog.Close(busydialog)" )

	xbmcgui.Dialog().ok("MyKo","בוצע","אנא הפעל מחדש את המכשיר")
	
else:
	xbmcgui.Dialog().ok("MyKo","בוצע","המערכת במכשיר זה מישונת ואל ניתנת לשדרוג")


